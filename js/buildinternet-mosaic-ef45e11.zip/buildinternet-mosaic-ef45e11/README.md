# Mosaic jQuery Plugin

Documentation can be found on the official project page: [http://www.buildinternet.com/project/mosaic/](http://www.buildinternet.com/project/mosaic/)

*** Changelog ***

3/17/11 - 1.0.1 Fix

	*Fixed bug with multiple boxes being triggered at the same time.
	*Added options to define overlay and backdrop elements

3/16/11 - Mosaic 1.0 Released

	*Automatically generate sliding boxes & captions
	*Animations include slide & fade with custom directions
	*Preloads images and displays them when page is loaded
	*Based on our original Sliding Boxes & Captions with jQuery post
